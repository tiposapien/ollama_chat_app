document.addEventListener('DOMContentLoaded', function() {
    const chatBox = document.getElementById('chat-box');
    const messageInput = document.getElementById('message-input');
    const modelSelect = document.getElementById('model-select');
    const sendButton = document.getElementById('send-button');
    const newChatButton = document.getElementById('new-chat-button');
    const deleteChatButton = document.getElementById('delete-chat-button');
    const chatLogsList = document.getElementById('chat-logs');

    let selectedChatFilename = null;
    const socket = io();

    /* ---- Loading Indicator ---- */
    let loadingIndicator = null;
    function showLoadingIndicator() {
        if (!loadingIndicator) {
            loadingIndicator = document.createElement('div');
            loadingIndicator.classList.add('loading-indicator');
            loadingIndicator.textContent = 'Thinking...';
            chatBox.appendChild(loadingIndicator);
        }
    }
    function hideLoadingIndicator() {
        if (loadingIndicator) {
            loadingIndicator.remove();
            loadingIndicator = null;
        }
    }
    /* -------------------------- */

    // Load models
    fetch('/api/models')
        .then(response => response.json())
        .then(data => {
            const models = data.models;
            if (models && models.length > 0) {
                models.forEach(model => {
                    const option = document.createElement('option');
                    option.value = model;
                    option.textContent = model;
                    modelSelect.appendChild(option);
                });
            }
        })
        .catch(error => console.error('Error fetching models:', error));

    // Load initial chat history
    fetch('/api/chat_history')
        .then(response => response.json())
        .then(data => renderChatHistory(data.chat_history))
        .catch(error => console.error('Error fetching chat history:', error));

    // Load list of chat logs
    function loadChatLogs() {
        fetch('/api/chat_logs')
            .then(response => response.json())
            .then(data => {
                chatLogsList.innerHTML = '';
                data.chat_logs.forEach(chat => {
                    const listItem = document.createElement('li');
                    listItem.textContent = chat.subject || 'Untitled Chat';
                    listItem.dataset.filename = chat.filename;
                    listItem.dataset.subject = chat.subject || 'Untitled Chat';
                    listItem.classList.add('chat-list-item');
                    listItem.addEventListener('click', () => selectChat(listItem));
                    listItem.addEventListener('dblclick', () => makeListItemEditable(listItem));
                    chatLogsList.appendChild(listItem);
                });
                if (selectedChatFilename) {
                    const items = chatLogsList.querySelectorAll('li');
                    items.forEach(item => {
                        if (item.dataset.filename === selectedChatFilename) {
                            item.classList.add('selected');
                        }
                    });
                }
            })
            .catch(error => console.error('Error fetching chat logs:', error));
    }
    loadChatLogs();

    function selectChat(listItem) {
        document.querySelectorAll('#chat-logs li').forEach(li => li.classList.remove('selected'));
        listItem.classList.add('selected');
        selectedChatFilename = listItem.dataset.filename;

        fetch('/api/load_chat', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({filename: selectedChatFilename})
        })
        .then(res => res.json())
        .then(data => {
            if (data.status) {
                chatBox.innerHTML = '';
                fetch('/api/chat_history')
                    .then(res => res.json())
                    .then(history => renderChatHistory(history.chat_history));
            } else {
                alert('Failed to load chat.');
            }
        })
        .catch(err => console.error('Error loading chat:', err));
    }

    // Inline subject editing
    function makeListItemEditable(listItem) {
        const currentSubject = listItem.dataset.subject;
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentSubject;
        input.classList.add('edit-input');
        listItem.innerHTML = '';
        listItem.appendChild(input);
        input.focus();

        input.addEventListener('blur', () => saveNewSubject(listItem, input.value.trim()));
        input.addEventListener('keydown', e => {
            if (e.key === 'Enter') {
                e.preventDefault();
                input.blur();
            }
        });
    }

    function saveNewSubject(listItem, newSubject) {
        if (!selectedChatFilename) {
            alert('Please select a chat to update.');
            return;
        }
        fetch('/api/update_chat_subject', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                filename: listItem.dataset.filename,
                subject: newSubject
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status) {
                listItem.textContent = newSubject || 'Untitled Chat';
                listItem.dataset.subject = newSubject || 'Untitled Chat';
                listItem.addEventListener('click', () => selectChat(listItem));
                listItem.addEventListener('dblclick', () => makeListItemEditable(listItem));
            } else {
                alert('Failed to update subject.');
            }
        })
        .catch(err => console.error('Error updating subject:', err));
    }

    newChatButton.addEventListener('click', () => location.reload());

    deleteChatButton.addEventListener('click', () => {
        if (selectedChatFilename) {
            fetch('/api/delete_chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ filename: selectedChatFilename })
            })
            .then(res => res.json())
            .then(data => {
                if (data.status) {
                    loadChatLogs();
                    selectedChatFilename = null;
                    chatBox.innerHTML = '';
                } else {
                    alert('Failed to delete chat.');
                }
            })
            .catch(err => console.error('Error deleting chat:', err));
        } else {
            alert('Please select a chat to delete.');
        }
    });

    // Shift+Enter to send
    messageInput.addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    sendButton.addEventListener('click', sendMessage);

    function sendMessage() {
        const message = messageInput.value.trim();
        const selectedModel = modelSelect.value;
        if (!selectedModel) {
            alert("Please select a model.");
            return;
        }
        if (message) {
            addMessageToChat('User', message);
            messageInput.value = '';
            // Show waiting indicator
            showLoadingIndicator();

            setTimeout(() => {
                socket.emit('send_message', {
                    model: selectedModel,
                    prompt: message
                });
            }, 0);
        }
    }

    // Streamed data
    socket.on('receive_message', data => {
        // As soon as we get something from the model, hide the indicator
        hideLoadingIndicator();

        const content = data.content;
        let botMessages = document.querySelectorAll('.bot-message[data-updating="true"]');
        let lastBotMessage = botMessages[botMessages.length - 1];

        if (!lastBotMessage) {
            lastBotMessage = addMessageToChat('Bot', '');
            lastBotMessage.setAttribute('data-updating', 'true');
        }
        let html = marked.parse(content);
        html = transformCustomTags(html);
        lastBotMessage.innerHTML = html;

        lastBotMessage.querySelectorAll('pre code').forEach(block => {
            hljs.highlightElement(block);
            addCopyButton(block);
        });
        chatBox.scrollTop = chatBox.scrollHeight;
    });

    socket.on('response_complete', () => {
        hideLoadingIndicator();
        const updatingBotMessages = document.querySelectorAll('.bot-message[data-updating="true"]');
        updatingBotMessages.forEach(msg => msg.removeAttribute('data-updating'));
        loadChatLogs();
    });

    socket.on('error', data => console.error('Error:', data.error));

    function renderChatHistory(chatHistory) {
        chatBox.innerHTML = '';
        chatHistory.forEach(msg => {
            const sender = msg.role === 'user' ? 'User' : 'Bot';
            addMessageToChat(sender, msg.content);
        });
    }

    function addMessageToChat(sender, message) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message-bubble');
        messageElement.classList.add(sender === 'User' ? 'user-message' : 'bot-message');
        let html = marked.parse(message);
        html = transformCustomTags(html);
        messageElement.innerHTML = html;

        messageElement.querySelectorAll('pre code').forEach(block => {
            hljs.highlightElement(block);
            addCopyButton(block);
        });
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
        return messageElement;
    }

    /* --- Custom <think> Tag Handling --- */
    function transformCustomTags(html) {
        // Only show if non-empty
        return html.replace(/<think>([\s\S]*?)<\/think>/gi, (match, p1) => {
            if (!p1.trim()) {
                // If empty, remove entirely
                return '';
            }
            return `
            <div class="custom-think-collapsible">
                <div class="think-summary">[Thought - Click to Expand]</div>
                <div class="think-content" style="display:none;">${p1}</div>
            </div>`;
        });
    }

    // Toggle on summary click
    document.addEventListener('click', e => {
        if (e.target && e.target.classList.contains('think-summary')) {
            const content = e.target.nextElementSibling;
            if (content) {
                const isVisible = (content.style.display === 'block');
                content.style.display = isVisible ? 'none' : 'block';
                e.target.textContent = isVisible
                  ? '[Thought - Click to Expand]'
                  : '[Thought - Click to Hide]';
            }
        }
    });

    // Add copy button to code blocks
    function addCopyButton(codeBlock) {
        const copyBtn = document.createElement('button');
        copyBtn.textContent = 'Copy';
        copyBtn.classList.add('copy-button');
        codeBlock.parentNode.insertBefore(copyBtn, codeBlock);
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(codeBlock.innerText || '').then(() => {
                copyBtn.textContent = 'Copied!';
                setTimeout(() => copyBtn.textContent = 'Copy', 1500);
            });
        });
    }
});