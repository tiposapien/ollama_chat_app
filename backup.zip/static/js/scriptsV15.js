document.addEventListener('DOMContentLoaded', function() {
    const chatBox = document.getElementById('chat-box');
    const messageInput = document.getElementById('message-input');
    const modelSelect = document.getElementById('model-select');
    const sendButton = document.getElementById('send-button');
    const newChatButton = document.getElementById('new-chat-button');
    const deleteChatButton = document.getElementById('delete-chat-button');
    const chatLogsList = document.getElementById('chat-logs');

    let selectedChatFilename = null;

    // Initialize Socket.IO client
    const socket = io();

    // Load available models
    fetch('/api/models')
        .then(response => response.json())
        .then(data => {
            const models = data.models;
            if (models && models.length > 0) {
                models.forEach(model => {
                    const option = document.createElement('option');
                    option.value = model;
                    option.textContent = model;
                    modelSelect.appendChild(option);
                });
            } else {
                console.warn('No models received.');
            }
        })
        .catch(error => {
            console.error('Error fetching models:', error);
        });

    // Fetch chat history and render it
    fetch('/api/chat_history')
        .then(response => response.json())
        .then(data => {
            const chatHistory = data.chat_history;
            renderChatHistory(chatHistory);
        })
        .catch(error => {
            console.error('Error fetching chat history:', error);
        });

    // Fetch chat logs and populate the list
    function loadChatLogs() {
        fetch('/api/chat_logs')
            .then(response => response.json())
            .then(data => {
                const chatLogs = data.chat_logs;
                chatLogsList.innerHTML = '';
                chatLogs.forEach(chat => {
                    const listItem = document.createElement('li');
                    listItem.textContent = chat.subject || 'Untitled Chat';
                    listItem.dataset.filename = chat.filename;

                    // Single click event to select and load chat
                    listItem.addEventListener('click', function() {
                        // Highlight selected chat
                        document.querySelectorAll('#chat-logs li').forEach(li => li.classList.remove('selected'));
                        listItem.classList.add('selected');
                        selectedChatFilename = chat.filename;

                        // Load the selected chat
                        fetch('/api/load_chat', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ filename: selectedChatFilename })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status) {
                                // Clear current chat box and render loaded chat
                                chatBox.innerHTML = '';
                                fetch('/api/chat_history')
                                    .then(response => response.json())
                                    .then(data => {
                                        const chatHistory = data.chat_history;
                                        renderChatHistory(chatHistory);
                                    });
                            } else {
                                alert('Failed to load chat.');
                            }
                        })
                        .catch(error => {
                            console.error('Error loading chat:', error);
                        });
                    });

                    chatLogsList.appendChild(listItem);
                });
            })
            .catch(error => {
                console.error('Error fetching chat logs:', error);
            });
    }

    loadChatLogs(); // Initial load of chat logs

    // Event listener for "New Chat" button
    newChatButton.addEventListener('click', function() {
        location.reload();  // Reload the page to start a new chat
    });

    // Event listener for "Delete Chat" button
    deleteChatButton.addEventListener('click', function() {
        if (selectedChatFilename) {
            fetch('/api/delete_chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filename: selectedChatFilename })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status) {
                    loadChatLogs();
                    selectedChatFilename = null;
                    alert('Chat deleted successfully.');
                } else {
                    alert('Failed to delete chat.');
                }
            })
            .catch(error => {
                console.error('Error deleting chat:', error);
            });
        } else {
            alert('Please select a chat to delete.');
        }
    });

    // Shift + Enter to send
    messageInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // Send button click event
    sendButton.addEventListener('click', sendMessage);

    // Function to send a message
    function sendMessage() {
        const message = messageInput.value.trim();
        const selectedModel = modelSelect.value;

        if (!selectedModel) {
            alert("Please select a model.");
            return;
        }

        if (message) {
            addMessageToChat('User', message);  // Render user input
            messageInput.value = '';  // Clear the input

            // Ensure the user's message is rendered before sending to the server
            setTimeout(() => {
                // Send the message to the server via Socket.IO
                socket.emit('send_message', {
                    model: selectedModel,
                    prompt: message
                });
            }, 0);
        }
    }

    // Listen for messages from the server
    socket.on('receive_message', function(data) {
        const content = data.content;

        // Update the last bot message or create a new one
        let botMessages = document.querySelectorAll('.bot-message[data-updating="true"]');
        let lastBotMessage = botMessages[botMessages.length -1];

        if (!lastBotMessage) {
            // Create a new bot message bubble
            lastBotMessage = addMessageToChat('Bot', '');
            lastBotMessage.setAttribute('data-updating', 'true');
        }

        lastBotMessage.innerHTML = marked.parse(content);
        chatBox.scrollTop = chatBox.scrollHeight;  // Auto-scroll to the bottom
    });

    // Listen for response completion from the server
    socket.on('response_complete', function() {
        // Remove the data-updating attribute
        let updatingBotMessages = document.querySelectorAll('.bot-message[data-updating="true"]');
        updatingBotMessages.forEach(msg => msg.removeAttribute('data-updating'));
        // Reload chat logs in case a new one was created
        loadChatLogs();
    });

    socket.on('error', function(data) {
        console.error('Error:', data.error);
    });

    // Function to add messages to the chat box
    function addMessageToChat(sender, message) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message-bubble');

        if (sender === 'User') {
            messageElement.classList.add('user-message');
        } else {
            messageElement.classList.add('bot-message');
        }

        // Apply markdown parsing
        messageElement.innerHTML = marked.parse(message);
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;

        return messageElement;
    }

    // Function to render chat history
    function renderChatHistory(chatHistory) {
        chatBox.innerHTML = '';
        chatHistory.forEach(message => {
            const sender = message.role === 'user' ? 'User' : 'Bot';
            addMessageToChat(sender, message.content);
        });
    }
});