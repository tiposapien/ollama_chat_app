document.addEventListener('DOMContentLoaded', function() {
    const chatBox = document.getElementById('chat-box');
    const messageInput = document.getElementById('message-input');
    const modelSelect = document.getElementById('model-select');
    const sendButton = document.getElementById('send-button');
    const newChatButton = document.getElementById('new-chat-button');
    const deleteChatButton = document.getElementById('delete-chat-button');
    const chatLogsList = document.getElementById('chat-logs');

    let selectedChatFilename = null;

    // Initialize Socket.IO client
    const socket = io();

    // Load available models
    fetch('/api/models')
        .then(response => response.json())
        .then(data => {
            const models = data.models;
            if (models && models.length > 0) {
                models.forEach(model => {
                    const option = document.createElement('option');
                    option.value = model;
                    option.textContent = model;
                    modelSelect.appendChild(option);
                });
            } else {
                console.warn('No models received.');
            }
        })
        .catch(error => {
            console.error('Error fetching models:', error);
        });

    // Fetch chat history
    fetch('/api/chat_history')
        .then(response => response.json())
        .then(data => {
            const chatHistory = data.chat_history;
            renderChatHistory(chatHistory);
        })
        .catch(error => {
            console.error('Error fetching chat history:', error);
        });

    // Fetch chat logs list
    function loadChatLogs() {
        fetch('/api/chat_logs')
            .then(response => response.json())
            .then(data => {
                const chatLogs = data.chat_logs;
                chatLogsList.innerHTML = '';
                chatLogs.forEach(chat => {
                    const listItem = document.createElement('li');
                    listItem.textContent = chat.subject || 'Untitled Chat';
                    listItem.dataset.filename = chat.filename;
                    listItem.dataset.subject = chat.subject || 'Untitled Chat';
                    listItem.classList.add('chat-list-item');

                    // Single click event: select and load chat
                    listItem.addEventListener('click', function() {
                        selectChat(listItem);
                    });

                    // Double click event: inline edit subject
                    listItem.addEventListener('dblclick', function() {
                        makeListItemEditable(listItem);
                    });

                    chatLogsList.appendChild(listItem);
                });

                // Reselect previously chosen chat, if any
                if (selectedChatFilename) {
                    const items = chatLogsList.querySelectorAll('li');
                    items.forEach(item => {
                        if (item.dataset.filename === selectedChatFilename) {
                            item.classList.add('selected');
                        }
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching chat logs:', error);
            });
    }
    loadChatLogs(); // Initial load

    // Select chat
    function selectChat(listItem) {
        document.querySelectorAll('#chat-logs li').forEach(li => li.classList.remove('selected'));
        listItem.classList.add('selected');
        selectedChatFilename = listItem.dataset.filename;

        fetch('/api/load_chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: selectedChatFilename })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status) {
                chatBox.innerHTML = '';
                fetch('/api/chat_history')
                    .then(response => response.json())
                    .then(data => {
                        renderChatHistory(data.chat_history);
                    });
            } else {
                alert('Failed to load chat.');
            }
        })
        .catch(error => {
            console.error('Error loading chat:', error);
        });
    }

    // Inline subject editing
    function makeListItemEditable(listItem) {
        const currentSubject = listItem.dataset.subject;
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentSubject;
        input.classList.add('edit-input');

        listItem.innerHTML = '';
        listItem.appendChild(input);
        input.focus();

        input.addEventListener('blur', function() {
            saveNewSubject(listItem, input.value.trim());
        });
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                input.blur();
            }
        });
    }

    function saveNewSubject(listItem, newSubject) {
        if (!selectedChatFilename) {
            alert('Please select a chat to update.');
            return;
        }
        fetch('/api/update_chat_subject', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: listItem.dataset.filename,
                subject: newSubject
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status) {
                listItem.textContent = newSubject || 'Untitled Chat';
                listItem.dataset.subject = newSubject || 'Untitled Chat';

                // Re-attach click listeners
                listItem.addEventListener('click', function() { selectChat(listItem); });
                listItem.addEventListener('dblclick', function() { makeListItemEditable(listItem); });

                alert('Subject updated successfully.');
            } else {
                alert('Failed to update subject.');
            }
        })
        .catch(error => {
            console.error('Error updating subject:', error);
        });
    }

    // New Chat
    newChatButton.addEventListener('click', function() {
        location.reload(); // Start fresh
    });

    // Delete Chat
    deleteChatButton.addEventListener('click', function() {
        if (selectedChatFilename) {
            fetch('/api/delete_chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filename: selectedChatFilename })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status) {
                    loadChatLogs();
                    selectedChatFilename = null;
                    alert('Chat deleted successfully.');
                    chatBox.innerHTML = '';
                } else {
                    alert('Failed to delete chat.');
                }
            })
            .catch(error => {
                console.error('Error deleting chat:', error);
            });
        } else {
            alert('Please select a chat to delete.');
        }
    });

    // Shift+Enter to send
    messageInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // Send button
    sendButton.addEventListener('click', sendMessage);

    function sendMessage() {
        const message = messageInput.value.trim();
        const selectedModel = modelSelect.value;

        if (!selectedModel) {
            alert("Please select a model.");
            return;
        }
        if (message) {
            addMessageToChat('User', message);
            messageInput.value = ''; 

            // Send to server
            setTimeout(() => {
                socket.emit('send_message', {
                    model: selectedModel,
                    prompt: message
                });
            }, 0);
        }
    }

    // Listen for server messages
    socket.on('receive_message', function(data) {
        const content = data.content;
        let botMessages = document.querySelectorAll('.bot-message[data-updating="true"]');
        let lastBotMessage = botMessages[botMessages.length - 1];

        if (!lastBotMessage) {
            lastBotMessage = addMessageToChat('Bot', '');
            lastBotMessage.setAttribute('data-updating', 'true');
        }
        lastBotMessage.innerHTML = marked.parse(content);
        chatBox.scrollTop = chatBox.scrollHeight;
    });

    // Response complete
    socket.on('response_complete', function() {
        let updatingBotMessages = document.querySelectorAll('.bot-message[data-updating="true"]');
        updatingBotMessages.forEach(msg => msg.removeAttribute('data-updating'));
        loadChatLogs();
    });

    socket.on('error', function(data) {
        console.error('Error:', data.error);
    });

    // Add message to chat
    function addMessageToChat(sender, message) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message-bubble');
        if (sender === 'User') {
            messageElement.classList.add('user-message');
        } else {
            messageElement.classList.add('bot-message');
        }
        messageElement.innerHTML = marked.parse(message);
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
        return messageElement;
    }

    // Render existing history
    function renderChatHistory(chatHistory) {
        chatBox.innerHTML = '';
        chatHistory.forEach(message => {
            const sender = message.role === 'user' ? 'User' : 'Bot';
            addMessageToChat(sender, message.content);
        });
    }
});