import os
import json
import requests
import threading
from flask import Flask, render_template, request, jsonify, session
from flask_socketio import SocketIO, emit
from flask_session import Session
from uuid import uuid4
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'fallback_secret')

# Configure Flask-Session
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = os.path.join(os.getcwd(), 'flask_session')
app.config['SESSION_PERMANENT'] = False
Session(app)

# Initialize SocketIO with manage_session=False
socketio = SocketIO(app, manage_session=False)

# Debug mode
DEBUG_MODE = True

def print_debug(message, color="default"):
    """Print debug messages in specified color if DEBUG_MODE is enabled."""
    if not DEBUG_MODE:
        return
    colors = {
        "default": "\033[0m",
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "magenta": "\033[95m",
        "cyan": "\033[96m",
        "white": "\033[97m"
    }
    color_code = colors.get(color, colors["default"])
    print(f"{color_code}{message}{colors['default']}")

# Log directory
LOG_DIR = os.path.join(os.getcwd(), 'chat_logs')
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR, exist_ok=True)

def save_chat_to_log(log_filename, chat_session):
    """Save the chat session to a log file in JSON format."""
    log_filepath = os.path.join(LOG_DIR, log_filename)
    with open(log_filepath, 'w', encoding='utf-8') as log_file:
        json.dump(chat_session, log_file, indent=2)

def get_chat_logs():
    """Get a list of chat log filenames and their metadata."""
    files = os.listdir(LOG_DIR)
    chat_logs = []
    for filename in files:
        if filename.startswith('deleted-') or not filename.endswith('.json'):
            continue
        log_filepath = os.path.join(LOG_DIR, filename)
        with open(log_filepath, 'r', encoding='utf-8') as log_file:
            chat_session = json.load(log_file)
            chat_logs.append({
                'filename': filename,
                'uuid': chat_session.get('uuid', ''),
                'datetime': chat_session.get('datetime', ''),
                'subject': chat_session.get('subject', 'Untitled Chat')
            })
    # Sort in descending order based on 'datetime'
    chat_logs.sort(key=lambda x: x['datetime'], reverse=True)
    return chat_logs

def load_chat_log(filename):
    """Load a chat session from a log file."""
    log_filepath = os.path.join(LOG_DIR, filename)
    if os.path.exists(log_filepath):
        with open(log_filepath, 'r', encoding='utf-8') as log_file:
            return json.load(log_file)
    return None

def delete_chat_log(filename):
    """Rename the chat log file to mark it as deleted."""
    log_filepath = os.path.join(LOG_DIR, filename)
    if os.path.exists(log_filepath):
        new_name = f"deleted-{filename}"
        os.rename(log_filepath, os.path.join(LOG_DIR, new_name))
        return True
    return False

@app.before_request
def initialize_session():
    """Initialize session variables if they are not set."""
    if 'log_filename' not in session:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        session['chat_uuid'] = uuid4().hex
        session['log_filename'] = f'chat_{timestamp}_{session["chat_uuid"]}.json'
        session['chat_datetime'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if 'chat_history' not in session:
        session['chat_history'] = []
    if 'chat_subject' not in session:
        session['chat_subject'] = ''

@app.route('/')
def index():
    session.clear()  # Clear session data to start a new chat
    return render_template('index.html')

@app.route('/api/models', methods=['GET'])
def get_models():
    """Fetch available models from the Ollama API."""
    try:
        response = requests.get('http://localhost:11434/api/tags')
        response.raise_for_status()
        data = response.json()
        models = [model.get('name') for model in data.get('models', [])]
        return jsonify({"models": models})
    except requests.exceptions.RequestException as e:
        app.logger.error(f"Error fetching models: {e}")
        return jsonify({"error": "Unable to fetch models"}), 500

@app.route('/api/chat_history', methods=['GET'])
def get_chat_history():
    """Return the current chat history."""
    chat_history = session.get('chat_history', [])
    return jsonify({"chat_history": chat_history})

@app.route('/api/chat_logs', methods=['GET'])
def list_chat_logs():
    """List all chat logs with their subjects."""
    chat_logs = get_chat_logs()
    return jsonify({"chat_logs": chat_logs})

@app.route('/api/load_chat', methods=['POST'])
def load_chat():
    """Load a chat session from a selected log file."""
    data = request.json
    filename = data.get('filename')
    if filename:
        chat_session = load_chat_log(filename)
        if chat_session:
            session['chat_history'] = chat_session.get('chat_logs', [])
            session['log_filename'] = filename
            session['chat_uuid'] = chat_session.get('uuid', '')
            session['chat_subject'] = chat_session.get('subject', '')
            session['chat_datetime'] = chat_session.get('datetime', '')
            session.modified = True
            return jsonify({"status": "Chat loaded successfully"}), 200
    return jsonify({"error": "Failed to load chat"}), 400

@app.route('/api/update_chat_subject', methods=['POST'])
def update_chat_subject():
    """Update the subject of a chat log."""
    data = request.json
    filename = data.get('filename')
    new_subject = data.get('subject')
    if filename and new_subject is not None:
        chat_session = load_chat_log(filename)
        if chat_session:
            chat_session['subject'] = new_subject
            save_chat_to_log(filename, chat_session)
            return jsonify({"status": "Subject updated successfully"}), 200
    return jsonify({"error": "Failed to update subject"}), 400

@app.route('/api/delete_chat', methods=['POST'])
def delete_chat():
    """Delete a selected chat log."""
    data = request.json
    filename = data.get('filename')
    if filename and delete_chat_log(filename):
        return jsonify({"status": "Chat deleted successfully"}), 200
    return jsonify({"error": "Failed to delete chat"}), 400

@socketio.on('send_message')
def handle_send_message(data):
    """Handle incoming messages from the client."""
    prompt = data.get('prompt')
    model = data.get('model', "llama3.2")

    user_message = {
        "role": "user",
        "content": prompt,
        "datetime": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "model": model
    }

    if not session.get('chat_subject'):
        # Set the chat subject as the first 30 characters
        session['chat_subject'] = prompt[:30]
    session['chat_datetime'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    session['chat_history'].append(user_message)
    session.modified = True

    obj_payload = {
        "model": model,
        "prompt": prompt,
        "messages": session['chat_history'],
        "stream": True
    }
    print_debug("Context history (messages):", color="yellow")
    print_debug(json.dumps(obj_payload['messages'], indent=2), color="cyan")

    try:
        response = requests.post('http://localhost:11434/api/chat', json=obj_payload, stream=True)
        response.raise_for_status()

        accumulated_message = ''
        sid = request.sid

        for line in response.iter_lines():
            if line:
                data_line = line.decode('utf-8')
                parsed_data = json.loads(data_line)

                if parsed_data.get('done'):
                    assistant_message = {
                        "role": "assistant",
                        "content": accumulated_message,
                        "datetime": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        "model": model
                    }
                    session['chat_history'].append(assistant_message)
                    session.modified = True

                    chat_session = {
                        "uuid": session.get('chat_uuid'),
                        "datetime": session.get('chat_datetime'),
                        "subject": session.get('chat_subject'),
                        "chat_logs": session.get('chat_history')
                    }
                    log_filename = session.get('log_filename')
                    threading.Thread(target=save_chat_to_log, args=(log_filename, chat_session)).start()

                    socketio.emit('response_complete', room=sid)
                    break
                else:
                    content = parsed_data['message']['content']
                    accumulated_message += content
                    socketio.emit('receive_message', {'content': accumulated_message}, room=sid)
    except requests.exceptions.RequestException as e:
        app.logger.error(f"Error in chat endpoint: {e}")
        emit('error', {'error': 'Unable to connect to Ollama API'})

if __name__ == '__main__':
    socketio.run(app, debug=True)